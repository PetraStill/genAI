"""Агент етапу 7: той самий граф, але база знань і замовлення - за MCP-сервером (shop_mcp.py).

Що змінилося порівняно з agent.py:
- retrieve і do_refund викликають інструменти MCP-сервера, а не локальний ретривер і функцію;
- новий намір "status" і вузол order_status (інструмент get_order) - нова можливість без нового коду пошуку;
- правила повернення (14 днів, статус замовлення) перевіряє сервер, а не промпт;
- вузли асинхронні: MCP-інструменти працюють лише через ainvoke, тому граф запускаємо через ainvoke / astream;
- промпт генерації одразу виправлений (V2 з 05_metrics).

Промпти й схеми ті самі, що в agent.py (скопійовані, щоб модуль не будував локальний ретривер під час імпорту).
"""

import json
import sys
from pathlib import Path
from typing import Annotated, Literal, TypedDict

from langchain_core.documents import Document
from langchain_core.messages import AIMessage, AnyMessage, SystemMessage
from langchain_core.tools import BaseTool
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages
from langgraph.types import interrupt
from pydantic import BaseModel, Field

from common import get_llm

llm = get_llm()


class State(TypedDict):
    messages: Annotated[list[AnyMessage], add_messages]
    question: str
    query: str
    documents: list[Document]
    attempts: int
    grounded: bool
    answer: str
    intent: str
    order_id: str | None
    reason: str | None
    approved: bool


class Grade(BaseModel):
    """Оцінка релевантності фрагмента бази знань питанню клієнта."""
    relevant: Literal["yes", "no"] = Field(description="yes - якщо фрагмент містить інформацію для відповіді на питання")


class Grounded(BaseModel):
    """Перевірка, що відповідь спирається на фрагменти бази знань."""
    grounded: Literal["yes", "no"] = Field(description="yes - якщо кожне твердження відповіді підтверджується фрагментами")


class Route(BaseModel):
    """Намір клієнта в останньому повідомленні."""
    intent: Literal["question", "refund", "status"] = Field(
        description="refund - клієнт просить оформити повернення; status - питає, де його замовлення або який у нього статус; "
                    "question - будь-яке інше питання")
    order_id: str | None = Field(default=None, description="номер замовлення у форматі A-1234, якщо він є десь у діалозі")
    reason: str | None = Field(default=None, description="причина повернення, якщо клієнт її назвав")


grader = llm.with_structured_output(Grade)
grounding_checker = llm.with_structured_output(Grounded)
router = llm.with_structured_output(Route)

GRADE_PROMPT = "Питання клієнта: {question}\n\nФрагмент бази знань:\n{doc}\n\nЧи містить фрагмент інформацію, потрібну для відповіді на питання?"
REWRITE_PROMPT = """Перепиши питання клієнта на короткий пошуковий запит до бази знань інтернет-магазину
(розділи: повернення, доставка, оплата, гарантія, замовлення, контакти).
Питання: {question}
Попередній запит, за яким нічого не знайшлося: {query}
Поверни лише новий запит, без пояснень."""
GENERATE_PROMPT = """Ти — асистент підтримки інтернет-магазину «ЇжакМаркет».
Відповідай ЛИШЕ на основі наведених нижче фрагментів бази знань. Не додавай фактів, яких у них немає.
Якщо з фрагментів випливає відповідь «ні» (послуга не надається, товар не можна повернути тощо), це теж відповідь: дай її.
Якщо питання складається з кількох частин, відповідай на кожну.
Відповідай рівно НЕМАЄ ВІДПОВІДІ, лише якщо фрагменти не містять інформації для відповіді.

Фрагменти бази знань:
{context}

Питання клієнта: {question}"""
GROUNDING_PROMPT = "Фрагменти бази знань:\n{context}\n\nВідповідь асистента:\n{answer}\n\nЧи підтверджується КОЖНЕ твердження відповіді фрагментами?"
ROUTE_PROMPT = "Ти — маршрутизатор підтримки інтернет-магазину. За діалогом визнач, чого хоче клієнт в ОСТАННЬОМУ повідомленні."
NO_ANSWER = "НЕМАЄ ВІДПОВІДІ"
FALLBACK = "На жаль, я не знайшов відповіді в базі знань. Передаю ваше питання оператору — він зв'яжеться з вами найближчим часом."
ASK_ORDER_ID = "Назвіть, будь ласка, номер замовлення (формат A-1234)."
DECLINED = "Добре, повернення не оформлюю. Чим ще можу допомогти?"


def shop_connection() -> dict:
    """Як підключатися до MCP-сервера магазину: клієнт сам запускає shop_mcp.py як підпроцес і говорить з ним через stdin/stdout."""
    return {"transport": "stdio", "command": sys.executable, "args": [str(Path(__file__).parent / "shop_mcp.py")]}


def redirect_mcp_server_logs(path: str = "data/mcp_server.log") -> None:
    """Потрібно лише в Jupyter: stdio-клієнт MCP пише логи сервера в sys.stderr, а в ноутбуці це не справжній файл
    (помилка UnsupportedOperation: fileno). Перенаправляємо логи сервера у файл."""
    import mcp.client.stdio as stdio
    stdio.stdio_client.__wrapped__.__defaults__ = (open(path, "a", encoding="utf-8"),)


def tool_text(result) -> str:
    """MCP-інструмент повертає список блоків контенту; нам потрібен їхній текст."""
    if isinstance(result, str):
        return result
    return "".join(block.get("text", "") for block in result if isinstance(block, dict))


def build_mcp_graph(tools: list[BaseTool], checkpointer=None, max_attempts: int = 2):
    """Граф агента, де пошук і дії - інструменти MCP-сервера. tools - результат load_mcp_tools / client.get_tools()."""
    tool = {t.name: t for t in tools}

    async def route(state: State) -> dict:
        decision = await router.ainvoke([SystemMessage(ROUTE_PROMPT), *state["messages"]])
        question = state["messages"][-1].content
        return {
            "intent": decision.intent, "order_id": decision.order_id, "reason": decision.reason,
            "question": question, "query": question, "attempts": 0, "documents": [], "answer": "",
        }

    async def retrieve(state: State) -> dict:
        found = json.loads(tool_text(await tool["search_knowledge_base"].ainvoke({"query": state["query"]})))
        return {"documents": [Document(page_content=f["text"], metadata={"source": f["source"]}) for f in found]}

    async def grade_documents(state: State) -> dict:
        prompts = [GRADE_PROMPT.format(question=state["question"], doc=doc.page_content) for doc in state["documents"]]
        grades = await grader.abatch(prompts)
        return {"documents": [doc for doc, g in zip(state["documents"], grades) if g.relevant == "yes"]}

    async def rewrite_query(state: State) -> dict:
        message = await llm.ainvoke(REWRITE_PROMPT.format(question=state["question"], query=state["query"]))
        return {"query": message.text.strip(), "attempts": state["attempts"] + 1}

    async def generate(state: State) -> dict:
        context = "\n\n".join(doc.page_content for doc in state["documents"])
        message = await llm.ainvoke(GENERATE_PROMPT.format(context=context, question=state["question"]))
        return {"answer": message.text}

    async def check_grounding(state: State) -> dict:
        if NO_ANSWER in state["answer"]:
            return {"grounded": False}
        context = "\n\n".join(doc.page_content for doc in state["documents"])
        result = await grounding_checker.ainvoke(GROUNDING_PROMPT.format(context=context, answer=state["answer"]))
        return {"grounded": result.grounded == "yes"}

    def fallback(state: State) -> dict:
        return {"answer": FALLBACK}

    def ask_order_id(state: State) -> dict:
        return {"answer": ASK_ORDER_ID}

    async def order_status(state: State) -> dict:
        order = json.loads(tool_text(await tool["get_order"].ainvoke({"order_id": state["order_id"]})))
        if "error" in order:
            return {"answer": f"{order['error']}. Перевірте, будь ласка, номер."}
        delivered = f", отримано {order['delivered_at']}" if order["delivered_at"] else ""
        return {"answer": f"Замовлення {order['order_id']}: {order['status']}{delivered}. Склад: {', '.join(order['items'])}."}

    def approve_refund(state: State) -> dict:
        decision = interrupt({"action": "issue_refund", "order_id": state["order_id"], "reason": state["reason"]})
        if decision == "yes":
            return {"approved": True}
        return {"approved": False, "answer": DECLINED}

    async def do_refund(state: State) -> dict:
        result = await tool["issue_refund"].ainvoke({"order_id": state["order_id"], "reason": state["reason"] or "не вказана"})
        return {"answer": tool_text(result)}

    def finish(state: State) -> dict:
        return {"messages": [AIMessage(state["answer"])]}

    def route_by_intent(state: State) -> Literal["retrieve", "ask_order_id", "approve_refund", "order_status"]:
        if state["intent"] == "question":
            return "retrieve"
        if not state["order_id"]:
            return "ask_order_id"
        return "approve_refund" if state["intent"] == "refund" else "order_status"

    def route_after_grade(state: State) -> Literal["generate", "rewrite_query", "fallback"]:
        if state["documents"]:
            return "generate"
        return "rewrite_query" if state["attempts"] < max_attempts else "fallback"

    def route_after_check(state: State) -> Literal["finish", "fallback"]:
        return "finish" if state["grounded"] else "fallback"

    def route_after_approval(state: State) -> Literal["do_refund", "finish"]:
        return "do_refund" if state["approved"] else "finish"

    builder = StateGraph(State)
    for node in [route, retrieve, grade_documents, rewrite_query, generate, check_grounding, fallback,
                 ask_order_id, order_status, approve_refund, do_refund, finish]:
        builder.add_node(node.__name__, node)

    builder.add_edge(START, "route")
    builder.add_conditional_edges("route", route_by_intent)
    builder.add_edge("retrieve", "grade_documents")
    builder.add_conditional_edges("grade_documents", route_after_grade)
    builder.add_edge("rewrite_query", "retrieve")
    builder.add_edge("generate", "check_grounding")
    builder.add_conditional_edges("check_grounding", route_after_check)
    builder.add_edge("fallback", "finish")
    builder.add_edge("ask_order_id", "finish")
    builder.add_edge("order_status", "finish")
    builder.add_conditional_edges("approve_refund", route_after_approval)
    builder.add_edge("do_refund", "finish")
    builder.add_edge("finish", END)
    return builder.compile(checkpointer=checkpointer or InMemorySaver())
