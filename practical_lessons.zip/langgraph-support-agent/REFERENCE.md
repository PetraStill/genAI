# Довідник: функції, параметри, аналоги

Короткий опис усього, що є в коді проєкту. Для кожного елемента:

- **Що** робить.
- **Як** реалізовано: на чому побудовано.
- **Змінити**: що можна підкрутити.
- **Аналоги**: чим замінити в іншому проєкті.

Порядок такий самий, як у ноутбуках: від моделі й пошуку до графа, eval, судді, MCP і сервісу. Схеми до всього цього є в `schemes.html`, а пояснення «чому так» - у `GUIDE.md`, `GUIDE_2.md` і `GUIDE_3.md`.

Версії: `langgraph 1.2.18`, `langchain 1.4.7`, `langchain-core 1.7.3` (див. `requirements.txt`).

---

## 1. Налаштування (`.env`)

| Змінна | Що робить | Як змінити |
|---|---|---|
| `GOOGLE_API_KEY` | ключ Gemini API | для іншого провайдера потрібен його ключ (`OPENAI_API_KEY`, `ANTHROPIC_API_KEY`) |
| `MODEL` | чат-модель у форматі `провайдер:модель` | `openai:gpt-4.1-mini`, `anthropic:claude-haiku-4-5`; потрібен пакет `langchain-<провайдер>` |
| `EMBEDDINGS_MODEL` | модель ембедингів для пошуку | `openai:text-embedding-3-small`; після зміни векторне сховище будується наново |
| `LLM_RPM` | ліміт запитів до LLM на хвилину (`0` - без ліміту) | безкоштовний Gemini flash-lite - 15 RPM, тому стоїть 14 |
| `LANGSMITH_TRACING`, `LANGSMITH_API_KEY`, `LANGSMITH_PROJECT` | трейсинг у LangSmith (лише `04`) | без ключа все працює, просто трейси нікуди не надсилаються |
| `OPERATOR_TOKEN` | токен ендпоінтів оператора в `app.py` | порожній - без захисту (лише локально); у Render генерується автоматично |
| `CHECKPOINT_DB` | файл SQLite з пам'яттю діалогів | за замовчуванням `data/checkpoints.sqlite` |
| `MCP_URL` | адреса MCP-сервера по HTTP | порожньо - сервіс сам запускає `shop_mcp.py` через stdio |
| `SHOP_TODAY` | «сьогодні» для правила 14 днів у `shop_mcp.py` | зафіксовано `2026-11-20`, щоб приклади не «старіли»; у продакшені - реальна дата |

`.env` ніколи не комітять і нікому не передають. Шаблон для заповнення - `.env.example`.

---

## 2. `common.py`: модель і пошук

### `get_llm(model=None)`
- **Що:** повертає чат-модель, через яку йдуть усі виклики LLM у проєкті.
- **Як:** `init_chat_model("провайдер:модель", temperature=0, rate_limiter=...)` з LangChain. Обмеження частоти робить `InMemoryRateLimiter`: `requests_per_second = LLM_RPM / 60`.
- **Змінити:**
  - аргумент `model` дає іншу модель для однієї задачі; наприклад, суддя може бути сильнішою моделлю, ніж агент;
  - `temperature=0` дає максимально стабільні відповіді (нові Gemini частково ігнорують цей параметр);
  - `max_retries` і `timeout` можна передати в `init_chat_model`.
- **Аналоги:**
  - класи провайдерів напряму (`ChatGoogleGenerativeAI`, `ChatOpenAI`, `ChatAnthropic`);
  - LiteLLM або OpenRouter, якщо потрібен один API до багатьох моделей;
  - для лімітів - повтори з backoff (`tenacity`) або квоти на боці провайдера.

### `load_corpus()`
- **Що:** читає `corpus/*.md` і ріже на чанки. Кожен розділ `## ...` стає окремим `Document` з `metadata["source"]` (ім'я файлу).
- **Як:** звичайний `str.split("\n## ")`. До кожного чанка додається заголовок файлу, щоб фрагмент мав контекст.
- **Змінити:** для більшої бази потрібне нарізання за розміром з перекриттям (overlap). У `metadata` можна покласти розділ, дату або мову, щоб потім фільтрувати.
- **Аналоги:**
  - `MarkdownHeaderTextSplitter` і `RecursiveCharacterTextSplitter` (`langchain-text-splitters`);
  - для PDF, DOCX і HTML - завантажувачі `langchain-community` або Unstructured;
  - семантичне нарізання за змістом.

### `get_retriever(k=3)`
- **Що:** будує векторне сховище з корпусу й повертає ретривер, який на запит віддає `k` найсхожіших фрагментів.
- **Як:**
  - ембединги рахуються через `init_embeddings(...)`;
  - сховище - `InMemoryVectorStore.from_documents(...)`, живе лише в пам'яті й будується наново при кожному запуску;
  - ретривер створює `.as_retriever(search_kwargs={"k": k})`.
- **Змінити:**
  - `k`: більше - вищий шанс знайти потрібне (hit@k), але більше роботи фільтру й довший контекст;
  - `search_type="mmr"` дає різноманітніші фрагменти;
  - `"similarity_score_threshold"` відсікає за порогом схожості.
- **Аналоги:**
  - сховища: Chroma або FAISS (локально, з диском), pgvector (якщо вже є Postgres), Qdrant, Pinecone, Weaviate;
  - гібридний пошук: BM25 + вектори через `EnsembleRetriever`;
  - переранжування: Cohere Rerank або cross-encoder.

### `show_graph(graph)`
- **Що:** малює граф у ноутбуці.
- **Як:** `graph.get_graph().draw_mermaid_png()` - PNG через сервіс mermaid.ink (потрібен інтернет). Без мережі друкується Mermaid-текст.
- **Аналоги:** `draw_mermaid()` (текст для README або GitHub), `draw_ascii()` (потрібен пакет `grandalf`), LangGraph Studio.

---

## 3. State: спільний стан графа

### `class State(TypedDict)`
- **Що:** перелік усіх даних, які передаються між вузлами. Кожен вузол повертає лише поля, які змінює, і LangGraph вливає їх у State.
- **Як:** `TypedDict` - звичайний словник з підказками типів, без перевірки під час виконання.
- **Змінити:** нове поле означає новий рядок у класі. Якщо поле має накопичуватися, а не перезаписуватися, йому потрібен reducer.
- **Аналоги:**
  - Pydantic `BaseModel` - з перевіркою типів, але повільніше;
  - `dataclass`;
  - готовий `MessagesState`, де вже є `messages` з `add_messages`.

| Поле | Етап | Значення |
|---|---|---|
| `question` | 1 | питання клієнта (останнє повідомлення) |
| `documents` | 1 | знайдені, а після фільтра - лише релевантні фрагменти |
| `answer` | 1 | відповідь, яку побачить клієнт |
| `query` | 2 | поточний пошуковий запит; після `rewrite_query` відрізняється від `question` |
| `attempts` | 2 | скільки разів уже переписували запит |
| `grounded` | 2 | результат `check_grounding` |
| `messages` | 3 | історія діалогу; reducer `add_messages` дописує, а не перезаписує |
| `intent`, `order_id`, `reason` | 3 | намір, номер замовлення, причина повернення (з `route`) |
| `approved` | 3 | рішення людини про повернення |

### `Annotated[list[AnyMessage], add_messages]`
- **Що:** reducer - функція, яка вирішує, як нове значення поля поєднується зі старим. `add_messages` дописує повідомлення в кінець, а повідомлення з тим самим `id` замінює.
- **Змінити:** для власного списку підійде `Annotated[list, operator.add]`.
- **Важливо:** поля без reducer'а просто перезаписуються. Тому `route` на кожній репліці скидає `attempts`, `documents` і `answer`: інакше checkpointer підставив би значення з минулого питання.

---

## 4. Структурований вихід (Pydantic-схеми)

`llm.with_structured_output(Схема)` змушує модель повернути об'єкт за схемою замість тексту. Описи полів (`Field(description=...)`) - це частина промпта: модель їх читає. Тому формулювання опису змінює поведінку.

| Схема | Де | Поля |
|---|---|---|
| `Grade` | `grade_documents` | `relevant: "yes" \| "no"` |
| `Grounded` | `check_grounding` | `grounded: "yes" \| "no"` |
| `Route` | `route` | `intent: "question" \| "refund"`, `order_id`, `reason` |
| `Verdict` / `VerdictV2` | суддя в `06` | `reasoning`, `correct`, `complete` |

- **Чому `"yes"`/`"no"`, а не `bool`:** дрібні моделі стабільніше заповнюють рядковий `Literal`.
- **Змінити:** можна додати поле `reason`, щоб бачити, чому фрагмент відкинуто (дорожче за токенами, але зручно для налагодження). Можна передати `method="json_schema"` або `"function_calling"`, якщо провайдер підтримує лише один із них.
- **Аналоги:** `PydanticOutputParser` з інструкцією формату в промпті, JSON mode провайдера, бібліотека Instructor.

---

## 5. Вузли графа

Вузол - звичайна функція `State → dict з оновленнями`. Її можна викликати й тестувати без графа.

### `route` (етап 3)
- **Що:**
  - за всією історією `messages` визначає намір і витягає номер замовлення та причину;
  - скидає поля минулої репліки.
- **Як:** один виклик `router.invoke([SystemMessage(ROUTE_PROMPT), *messages])` зі схемою `Route`.
- **Змінити:**
  - новий намір (скасування, статус замовлення) - значення в `Literal` плюс нова гілка в `route_by_intent`;
  - формат номера задається в описі поля `order_id`.
- **Аналоги:**
  - класифікатор на ембедингах (дешевше, без LLM);
  - правила й regex для очевидних випадків;
  - агент з tool calling (`create_agent`), де модель сама обирає інструмент. Гнучкіше, але менш передбачувано.

### `retrieve` (етап 1)
- **Що:** `retriever.invoke(state["query"])` дає `k` фрагментів.
- **Змінити:** див. `get_retriever`. Шукаємо за `query`, а не `question`, щоб після переписування пошук ішов за новим формулюванням.

### `grade_documents` (етап 2)
- **Що:** LLM оцінює кожен фрагмент (yes/no) і залишає лише релевантні.
- **Як:** `grader.batch(prompts)`, тобто `k` паралельних викликів зі схемою `Grade`.
- **Змінити:**
  - текст `GRADE_PROMPT`;
  - `config={"max_concurrency": N}` у `.batch()`, якщо впираєтеся в ліміт;
  - один виклик на всі фрагменти одразу - дешевше, але оцінка грубіша.
- **Аналоги:** reranker-модель з порогом, поріг схожості у векторному пошуку, Self-RAG / CRAG як готові патерни.
- **Метрики в `05`:** recall, precision і витік фільтра.

### `rewrite_query` (етап 2)
- **Що:** переформульовує запит і збільшує `attempts` на 1.
- **Як:** `llm.invoke(REWRITE_PROMPT)`. Промпт перелічує розділи бази й показує попередній невдалий запит.
- **Аналоги:**
  - multi-query (кілька формулювань одразу, `MultiQueryRetriever`);
  - HyDE (шукати за згенерованою гіпотетичною відповіддю);
  - декомпозиція складного питання на підпитання.

### `generate` (етап 1, суворий промпт з етапу 2)
- **Що:** відповідає лише за фрагментами. Якщо відповіді немає, пише маркер `НЕМАЄ ВІДПОВІДІ`.
- **Як:** `llm.invoke(generate_prompt.format(context=..., question=...))`. Фрагменти склеюються через `"\n\n"`.
- **Змінити:**
  - `GENERATE_PROMPT_V2` у `agent.py` дозволяє відповідь «ні» та відповідь на кожну частину питання (виправлення з `05`);
  - можна вимагати цитати джерел;
  - можна стрімити токени клієнту (`stream_mode="messages"`).
- **Аналоги:** відповідь з посиланнями на фрагменти (citations), структурований вихід `{answer, sources}`.

### `check_grounding` (етап 2)
- **Що:** перевіряє, чи кожне твердження відповіді підтверджене фрагментами. На маркері `НЕМАЄ ВІДПОВІДІ` одразу повертає `False` без виклику LLM.
- **Як:** `grounding_checker` зі схемою `Grounded`.
- **Аналоги:** NLI-модель (entailment), метрика faithfulness з RAGAS, перевірка цитат.

### `fallback` (етап 2)
- **Що:** фіксована чесна відмова `FALLBACK` без LLM. Текст узгоджують з бізнесом.
- **Змінити:** у продакшені тут створюють тікет або передають діалог оператору.

### `ask_order_id`, `approve_refund`, `do_refund`, `finish` (етап 3)
- `ask_order_id` - фіксоване питання про номер замовлення `ASK_ORDER_ID`.
- `approve_refund`:
  - викликає `interrupt({...})`, і граф зупиняється до рішення людини;
  - продовжує `graph.invoke(Command(resume="yes" | "no"), config)` з тим самим `thread_id`;
  - після resume вузол виконується **з першого рядка**, тому до `interrupt()` не ставлять побічних дій.
- `do_refund` викликає інструмент `issue_refund`. Потрапити сюди можна лише через `approve_refund`: безпеку дає структура графа, а не промпт.
- `finish` - єдина точка виходу: дописує `answer` в `messages`.
- **Аналоги підтвердження:**
  - статичні breakpoints `compile(interrupt_before=["do_refund"])`;
  - `HumanInTheLoopMiddleware` для агентів `create_agent` з LangChain.

### `issue_refund` (`@tool`)
- **Що:** фіктивне повернення коштів. Декоратор `@tool` дає функції ім'я, опис і схему аргументів.
- **Змінити:** у реальній системі тут виклик API платіжної системи або CRM. Цей самий інструмент можна віддати моделі через `llm.bind_tools([...])` або винести в MCP-сервер (тема наступного заняття).

---

## 6. Роутери (умовні ребра)

Роутер читає State і повертає **ім'я наступного вузла**. Роутери не викликають LLM і не змінюють State. Анотація `Literal[...]` у типі повернення потрібна, щоб LangGraph намалював умовні ребра.

| Роутер | Після вузла | Логіка |
|---|---|---|
| `route_by_intent` | `route` | питання → `retrieve`; повернення з номером → `approve_refund`; без номера → `ask_order_id` |
| `route_after_grade` | `grade_documents` | є релевантні → `generate`; порожньо й `attempts < max_attempts` → `rewrite_query`; інакше → `fallback` |
| `route_after_check` | `check_grounding` | `grounded` → `finish`, інакше → `fallback` |
| `route_after_approval` | `approve_refund` | `approved` → `do_refund`, інакше → `finish` |

- **Змінити:** нова гілка - це нове значення в `Literal`, нова умова й новий вузол.
- **Аналоги:**
  - `Command(goto="вузол", update={...})`, повернений із самого вузла: вузол сам обирає наступний крок;
  - `Send` для паралельного розгалуження (map-reduce).

---

## 7. Збірка і запуск графа

### `build_graph(max_attempts=2, generate_prompt=GENERATE_PROMPT)` (`agent.py`)
- **Що:** збирає фінальний граф етапу 3. Параметри потрібні, щоб у `05` порівнювати конфігурації без копіювання коду.
- **Параметри:**
  - `max_attempts` - скільки разів можна переписати запит. `1` економить виклики на питаннях поза базою; `0` вимикає цикл;
  - `generate_prompt` - промпт генерації (`GENERATE_PROMPT` або `GENERATE_PROMPT_V2`).
- **Як:**
  - `StateGraph(State)`;
  - `add_node`, `add_edge`, `add_conditional_edges`;
  - `compile(checkpointer=InMemorySaver())`.

### `compile(checkpointer=...)`
- **Що:** перевіряє граф і робить з нього виконуваний об'єкт.
- **Checkpointer:** зберігає State після кожного кроку під `thread_id`. Без нього не працюють пам'ять між репліками і `interrupt`.
- **Аналоги `InMemorySaver`:**
  - `SqliteSaver` (`langgraph-checkpoint-sqlite`);
  - `PostgresSaver` (`langgraph-checkpoint-postgres`) - стандарт для продакшену;
  - Redis-saver.

  Код графа при заміні не змінюється.

### `graph.invoke(input, config)` і `graph.stream(..., stream_mode=...)`
- **`input`:**
  - етапи 1-2: `{"question": ...}`;
  - етап 3: `{"messages": [HumanMessage(...)]}` - лише **нове** повідомлення, історію підставить checkpointer;
  - продовження після паузи: `Command(resume=...)`.
- **`config`:**
  - `{"configurable": {"thread_id": "..."}}` - ідентифікатор діалогу. Інший `thread_id` - інша пам'ять;
  - `recursion_limit` - аварійна зупинка: `GraphRecursionError` після N кроків. У LangGraph 1.2 за замовчуванням 10 007, тому для циклів ліміт краще задавати явно;
  - `run_name`, `tags`, `metadata` - мітки для трейсів LangSmith (`04`);
  - `callbacks` - обробники подій, наприклад `LLMCounter` у `evaluation.py`.
- **`stream_mode`:**
  - `"updates"` - що змінив кожен вузол (так ми бачимо шлях);
  - `"values"` - повний State після кожного кроку;
  - `"messages"` - токени LLM для стрімінгу клієнту;
  - `"custom"` - власні події з вузлів.
- **Інше:**
  - `graph.get_state(config)` - поточний State треду (зокрема, на якому вузлі граф стоїть на паузі);
  - `get_state_history` - усі збережені кроки.

### `set_llm_cache(InMemoryCache())` (`04`)
- **Що:** повторний **точно такий самий** запит до LLM береться з кешу без виклику моделі.
- **Аналоги:**
  - `SQLiteCache` (переживає перезапуск);
  - кеш на рівні вузла: `CachePolicy` плюс `compile(cache=...)`;
  - семантичний кеш за схожістю ембедингів (Redis). Про ризики семантичного кешу див. `GUIDE.md`.

---

## 8. Eval (`evaluation.py`, `evals/`, `05_metrics`)

### `evals/dataset.json`: розмітка одного питання
| Поле | Що означає |
|---|---|
| `id`, `question` | ідентифікатор і текст питання |
| `kind` | тип: `в базі`, `поза базою`, `повернення`, `неоднозначний`; метрики рахуються окремо для кожного |
| `source` | файл бази, де лежить відповідь (для hit@3, recall, precision) |
| `facts` | групи варіантів підрядків: `[["14"], ["днів", "дні"]]` означає «є 14 **і** (днів **або** дні)» |
| `reference` | еталонна відповідь, написана людиною (для судді в `06`) |
| `order_id` | очікуваний номер замовлення (для повернень) |

Щоб додати свій кейс, допишіть об'єкт у файл і перезапустіть ноутбук (Restart Kernel and Run All). Новий кейс потребує нового прогону агента, тобто `RERUN = True`.

### `LLMCounter(BaseCallbackHandler)`
- **Що:** рахує виклики моделі й токени за один прогін.
- **Як:** колбек `on_llm_end` читає `usage_metadata` з кожної відповіді.
- **Аналоги:** готовий `UsageMetadataCallbackHandler` / `get_usage_metadata_callback()` з `langchain_core`; підрахунок вартості в LangSmith або Langfuse.

### `run_case(graph, case)`
- **Що:** проганяє одне питання в новому `thread_id` через `stream_mode="updates"`. Записує трейс:
  - `path`, `retrieved`, `kept`, `queries`;
  - `intent`, `order_id`, `draft`, `grounded`, `answer`, `paused`;
  - `seconds`, `llm_calls`, токени.
- **Змінити:** щоб рахувати нову метрику, спершу запишіть у трейс потрібне поле.

### `collect(graph, dataset, name, rerun=False)`
- **Що:** повертає трейси з `evals/runs_<name>.json`. Агента проганяє, лише якщо файлу немає або `rerun=True`.
- **Навіщо:** прогін дорогий (виклики LLM), а метрики з файлу можна перераховувати скільки завгодно разів безкоштовно.

### Метрики в `05_metrics`
| Функція / метрика | Що вимірює | Вузол |
|---|---|---|
| `intent_ok`, `order_ok` | точність наміру й номера замовлення | `route` |
| hit@3 | чи є потрібний файл серед знайдених | `retrieve` |
| recall фільтра | чи залишив фільтр потрібний фрагмент, якщо пошук його знайшов | `grade_documents` |
| precision фільтра | яка частка залишених фрагментів справді потрібна | `grade_documents` |
| витік фільтра | чи пропустив фільтр щось на питаннях поза базою | `grade_documents` |
| хибні відмови / галюцинації | матриця «відповідь є в базі × агент відповів» | `generate`, `check_grounding` |
| `has_facts(answer, facts)` | чи є в відповіді потрібні підрядки | весь агент |
| `llm_calls`, `tokens`, `seconds` | вартість за типами питань | весь агент |
| `loop_frames(trace)` | таблиця «кадр за кадром» для циклу rewrite | роутер після grade |
| `summary(traces)` | зведення метрик для порівняння конфігурацій | - |

Інструменти для власного проєкту:
- **готові метрики:** RAGAS (faithfulness, context precision/recall), DeepEval, TruLens;
- **прогони й порівняння:** `langsmith.evaluate`, promptfoo.

---

## 9. LLM-суддя і продакшен (`06_judge_production`)

### `Verdict` / `VerdictV2`
- **Що:** рубрика судді у вигляді Pydantic-схеми:
  - `reasoning` - обґрунтування; стоїть першим, щоб модель спершу міркувала, а потім ставила оцінку;
  - `correct` - не суперечить еталону й нічого не вигадує;
  - `complete` - відповідає на всі частини питання.
- **Змінити:** опис поля - це і є критерій. `VerdictV2` змінює лише опис `complete`, і згода з людиною зростає з 83% до 100%. Шкала 1-5 замість yes/no дає більше нюансів, але гіршу відтворюваність.

### `grade_answer(judge, question, answer, reference)`
- **Що:** підставляє в `JUDGE_PROMPT` три рядки (питання, еталон, відповідь агента) і повертає вердикт плюс `pass = correct and complete`.
- **Без еталона:** передається `NO_REFERENCE`, і суддя оцінює «за власним розумінням». Він перевіряє правдоподібність, а не правду (67% згоди).

### Калібрування: `judge_calibration(judge, with_reference=True)` і `agreement(verdicts)`
- **Що:** суддю проганяють на `evals/judge_calibration.json` (12 відповідей з відомою людською оцінкою) і рахують частку збігів.
- **Правило:** судді, якого не перевірили на відомих відповідях, не довіряють.

### `cached(name, compute)`
- **Що:** результат з `evals/<name>.json` або обчислення зі збереженням. `RERUN = True` змушує перерахувати.

### `online_metrics(traces)`
- **Що:** метрики, які можна рахувати на живому трафіку **без еталона**:
  - частка `fallback`;
  - частка відкинутих `check_grounding`;
  - виклики LLM на запит;
  - p95 часу відповіді.
- **Аналоги:** дашборди LangSmith, Langfuse, Arize Phoenix; алерти в Grafana.

### `GATES`, `release_metrics(traces)`, `gate(metrics)`
- **Що:** ворота релізу. `GATES` задає пороги бізнесу: `"галюцинації": ("max", 0.0)`, `"хибні відмови": ("max", 0.10)`. Функція `gate` повертає список порушень; порожній список означає, що версію можна випускати.
- **Змінити:** пороги задає бізнес. Новий поріг - нова пара в `GATES` і нова метрика в `release_metrics`.
- **Аналоги:** pytest-тести з порогами в CI (GitHub Actions), `langsmith.evaluate` з порівнянням експериментів, promptfoo assertions.

### Що замінити для продакшену
| У проєкті | У продакшені |
|---|---|
| `InMemorySaver` | `PostgresSaver` |
| `InMemoryVectorStore` | pgvector, Qdrant, Chroma з диском |
| виклик з ноутбука | LangGraph Server або FastAPI |
| `Command(resume=...)` руками | UI оператора з кнопками «так» / «ні» |
| `LLM_RPM` | повтори з backoff, fallback-модель, секрети в менеджері секретів |
| `evals/*.json` | датасети й експерименти в LangSmith / Langfuse |

---

## 10. MCP-сервер (`shop_mcp.py`, `07_mcp`)

### `mcp = FastMCP("ijak-market", instructions=...)`
- **Що:** MCP-сервер з офіційного Python SDK (`mcp`). `instructions` - загальний опис сервера для клієнта.
- **Запуск:** `mcp.run()` - stdio (клієнт стартує сервер як підпроцес); `mcp.run(transport="streamable-http")` - мережевий сервіс (у нас `python shop_mcp.py --http`, порт `MCP_PORT`, за замовчуванням 8001).
- **Аналоги:** пакет `fastmcp` (розширена версія з композицією серверів і проксі), MCP SDK для TypeScript, Java, Go; готові сервери з каталогу MCP.

### `@mcp.tool()`: `search_knowledge_base(query, k=3)`, `get_order(order_id)`, `issue_refund(order_id, reason)`
- **Що:** інструменти, які бачить будь-який клієнт.
- **Як:** назва - ім'я функції, опис - docstring, JSON-схема аргументів - type hints. Повертають рядок; списки й об'єкти - як JSON-рядок.
- **Правила:** `issue_refund` перевіряє, що замовлення існує, має статус «доставлено», минуло не більше `RETURN_DAYS = 14` днів від `delivered_at` до `TODAY`, і повернення ще не оформлювали. Оформлені повернення пишуться в `data/refunds.json`.
- **Змінити:**
  - новий інструмент - нова функція з `@mcp.tool()`, клієнти побачать його після перепідключення;
  - docstring - це промпт для моделі, яка обирає інструмент: пишіть, **коли** його викликати;
  - повертайте структуровані дані (`dict` / Pydantic) - SDK віддасть і текст, і `structuredContent`.
- **Аналоги:** REST API + OpenAPI-схема (інструменти через `OpenAPIToolkit`), function calling провайдера напряму.

### `@mcp.resource("kb://{name}")`
- **Що:** ресурс - дані для читання за URI-шаблоном. Тут повний текст документа бази знань.
- **Відмінність від tool:** ресурс не має побічних ефектів і зазвичай його обирає застосунок або людина, а не модель.
- **Змінити:** `@mcp.prompt()` додає третій тип можливостей - шаблони промптів, які сервер пропонує клієнту.

### `_load_index()` і `data/kb_index.json`
- **Що:** ембединги корпусу рахуються один раз і зберігаються на диск разом з «відбитком» (`sha256` тексту корпусу й назви моделі). Якщо корпус або модель змінилися, індекс перебудовується.
- **Аналоги:** Chroma / FAISS з `persist_directory`, pgvector; у сервері - будь-яке векторне сховище.

---

## 11. Агент з MCP (`agent_mcp.py`, `07_mcp`)

### `shop_connection()`
- **Що:** параметри підключення до сервера для `MultiServerMCPClient`: `{"transport": "stdio", "command": python, "args": ["shop_mcp.py"]}`.
- **Змінити:** HTTP-сервер - `{"transport": "streamable_http", "url": "http://127.0.0.1:8001/mcp"}`; кілька серверів - кілька ключів у словнику.

### `MultiServerMCPClient` і `client.session("shop")` + `load_mcp_tools(session)`
- **Що:** клієнт з `langchain-mcp-adapters`; перетворює MCP-інструменти на LangChain `BaseTool`.
- **Важливо:** `client.get_tools()` без сесії відкриває **нову сесію на кожен виклик інструмента** (для stdio - новий процес сервера). Для сервісу й циклу викликів тримайте одну сесію: `async with client.session(...)`.
- **Асинхронність:** MCP-інструменти працюють лише через `await tool.ainvoke(...)`.
- **Параметри:** `tool_name_prefix=True` додає ім'я сервера до назв (якщо в різних серверів однакові інструменти); `tool_interceptors` - обгортки викликів (логування, перевірки).
- **Аналоги:** офіційний `mcp.ClientSession` напряму (у `07` показано «голий» протокол), MCP-підтримка в OpenAI Agents SDK, Claude Agent SDK.

### `redirect_mcp_server_logs(path="data/mcp_server.log")`
- **Що:** лише для Jupyter. stdio-клієнт пише логи сервера в `sys.stderr`, а в ноутбуці це не справжній файл (`UnsupportedOperation: fileno`). Функція перенаправляє логи у файл.

### `tool_text(result)`
- **Що:** MCP-інструмент повертає список блоків контенту (`[{"type": "text", "text": ...}]`); функція склеює текст.

### `build_mcp_graph(tools, checkpointer=None, max_attempts=2)`
- **Що:** граф етапу 3 з трьома змінами:
  - `retrieve` і `do_refund` викликають MCP-інструменти;
  - новий намір `status` у `Route` і вузол `order_status` (інструмент `get_order`, відповідь без LLM);
  - вузли `async def`.
- **Параметри:** `tools` - результат `load_mcp_tools`; `checkpointer` - `InMemorySaver` (за замовчуванням) або `AsyncSqliteSaver` / `AsyncPostgresSaver` для сервісу.
- **Запуск:** `await graph.ainvoke(...)`, `async for step in graph.astream(...)`, `await graph.aget_state(config)`.

### `arun_case`, `acollect` (`evaluation.py`)
- **Що:** асинхронні версії `run_case` і `collect` для графа з MCP. Трейси - `evals/runs_mcp.json`.

---

## 12. Сервіс і реліз (`app.py`, `eval_gate.py`, `08_deploy`)

### `lifespan(app)`
- **Що:** код старту й зупинки FastAPI-застосунку. Один раз відкриває MCP-сесію і з'єднання з SQLite (через `AsyncExitStack`), будує граф, створює таблицю `approvals`. На зупинці все закривається.
- **Аналоги:** `@app.on_event("startup")` (застаріле), залежності FastAPI з `yield` для ресурсів на запит.

### `AsyncSqliteSaver.from_conn_string(path)`
- **Що:** checkpointer у файлі SQLite (пакет `langgraph-checkpoint-sqlite`). Пам'ять діалогів і паузи `interrupt` переживають перезапуск.
- **Аналоги:** `AsyncPostgresSaver` (`langgraph-checkpoint-postgres`) - для кількох копій сервісу й платформ без постійного диска; Redis-saver.

### Ендпоінти
| Ендпоінт | Модель запиту / відповіді | Примітка |
|---|---|---|
| `POST /chat` | `ChatIn {message, thread_id?}` → `ChatOut {thread_id, status, answer, path}` | без `thread_id` починається новий діалог |
| `GET /threads/{id}` | історія `messages` і `waiting_approval` | читає checkpointer |
| `GET /approvals` | список `{thread_id, order_id, reason, created_at}` | `X-Operator-Token` |
| `POST /approvals/{id}` | `DecisionIn {decision: "yes" / "no"}` → `ChatOut` | `Command(resume=...)`; `404`, якщо тред не чекає |
| `GET /metrics` | частка fallback, відкинуті `check_grounding`, виклики LLM, p95, кількість очікувань | рахується з `data/requests.jsonl` |
| `GET /health` | `{"status": "ok"}` | для `healthCheckPath` платформи |

- **`require_operator`:** залежність FastAPI, що порівнює заголовок `X-Operator-Token` з `OPERATOR_TOKEN`. Аналоги: OAuth2 / JWT (`fastapi.security`), сесії, API-шлюз з автентифікацією.
- **`run_graph(graph_input, thread_id, kind)`:** запускає граф з `LLMCounter`, при `interrupt` записує запит у таблицю `approvals`, пише рядок у журнал `requests.jsonl`. Помилка графа - `502` з дружнім повідомленням, деталі - у лог.
- **Змінити:** стрімінг відповіді клієнту - `StreamingResponse` + `stream_mode="messages"`; черга для довгих запитів; rate limit (наприклад, `slowapi`).
- **Аналоги сервісу:** LangGraph Server (конфігурація `langgraph.json` і команда `langgraph dev`; у проєкті не використовується) - готові ендпоінти тредів, запусків і interrupt; LangServe (застаріле); Flask / Django.

### `eval_gate.py`
- **Запуск:** `python eval_gate.py` (збережені трейси), `--runs файл.json`, `--rerun` (новий прогін агента з MCP).
- **`GATES`:** галюцинації `max 0%`, хибні відмови `max 10%`, факти правильні `min 90%`, намір `min 95%`, повернення на паузі з правильним номером `min 100%`.
- **Код виходу:** `0` - реліз дозволено, `1` - заблоковано. CI сприймає `1` як провал.
- **Змінити:** додати суддю з `06` як метрику; окремі пороги для різних типів питань.

### Деплой-файли
| Файл | Що робить |
|---|---|
| `requirements-service.txt` | залежності сервісу без Jupyter і pandas |
| `Dockerfile` | образ на `python:3.12-slim`: спершу залежності (кешований шар), потім код; запуск не від root; `HEALTHCHECK` |
| `.dockerignore` | не пускає в образ `.env`, ноутбуки, `evals/`, локальні бази |
| `render.yaml` | Blueprint для Render: `buildCommand`, `startCommand`, `healthCheckPath`, `GOOGLE_API_KEY` (`sync: false` - вводиться вручну), `OPERATOR_TOKEN` (`generateValue: true`) |
| `.github/workflows/eval-gate.yml` | на кожен pull request: встановити залежності, `eval_gate.py --rerun` з секретом `GOOGLE_API_KEY`; без секрету - перевірка збережених трейсів |

- **Аналоги хостингу:** Google Cloud Run, Fly.io, Railway (з Docker), Hugging Face Spaces, LangGraph Platform; свій сервер з Docker Compose.
