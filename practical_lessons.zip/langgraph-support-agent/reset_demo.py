"""Скидає демо-стан перед заняттям: оформлені повернення, пам'ять діалогів, журнал запитів.

    python reset_demo.py

Нічого з корпусу, замовлень і індексу бази знань не чіпає.
"""

from pathlib import Path

DATA = Path(__file__).parent / "data"
STATE = ["refunds.json", "checkpoints.sqlite", "checkpoints.sqlite-shm", "checkpoints.sqlite-wal",
         "requests.jsonl", "mcp_server.log"]

for name in STATE:
    path = DATA / name
    if path.exists():
        path.unlink()
        print("видалено:", path.name)
print("Демо-стан скинуто. Тепер повернення A-2001 пройде з чистого листа.")
