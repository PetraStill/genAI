"""MCP-сервер магазину «ЇжакМаркет»: база знань і замовлення як інструменти для будь-якого MCP-клієнта.

Запуск:
    python shop_mcp.py                 # stdio: клієнт сам запускає сервер як підпроцес (так робить агент і Claude Desktop)
    python shop_mcp.py --http          # streamable HTTP на http://127.0.0.1:8001/mcp (окремий сервіс)

Бізнес-правила (чи можна повернути замовлення) живуть тут, на боці сервера, а не в промпті агента.
"""

import hashlib
import json
import math
import os
import sys
from datetime import date
from pathlib import Path

from mcp.server.fastmcp import FastMCP

from common import CORPUS_DIR, load_corpus

DATA_DIR = Path(__file__).parent / "data"
ORDERS_FILE = DATA_DIR / "orders.json"
REFUNDS_FILE = DATA_DIR / "refunds.json"
INDEX_FILE = DATA_DIR / "kb_index.json"
RETURN_DAYS = 14
# Дата «сьогодні» для правила 14 днів. Зафіксована, щоб приклади курсу не «старіли»; у продакшені - date.today().
TODAY = date.fromisoformat(os.getenv("SHOP_TODAY", "2026-11-20"))

mcp = FastMCP("ijak-market", instructions="Інструменти підтримки інтернет-магазину «ЇжакМаркет»: пошук у базі знань і робота із замовленнями.")


# ---------- база знань: ембединги рахуються один раз і зберігаються на диск ----------

def _embeddings():
    from langchain.embeddings import init_embeddings
    return init_embeddings(os.getenv("EMBEDDINGS_MODEL", "google_genai:gemini-embedding-001"))


def _load_index() -> list[dict]:
    docs = load_corpus()
    fingerprint = hashlib.sha256(("".join(d.page_content for d in docs) + os.getenv("EMBEDDINGS_MODEL", "")).encode()).hexdigest()
    if INDEX_FILE.exists():
        cached = json.loads(INDEX_FILE.read_text(encoding="utf-8"))
        if cached["fingerprint"] == fingerprint:
            return cached["chunks"]
    vectors = _embeddings().embed_documents([d.page_content for d in docs])
    chunks = [{"source": d.metadata["source"], "text": d.page_content, "vector": v} for d, v in zip(docs, vectors)]
    INDEX_FILE.write_text(json.dumps({"fingerprint": fingerprint, "chunks": chunks}, ensure_ascii=False), encoding="utf-8")
    return chunks


_index: list[dict] | None = None


def _cosine(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    return dot / (math.sqrt(sum(x * x for x in a)) * math.sqrt(sum(y * y for y in b)))


@mcp.tool()
def search_knowledge_base(query: str, k: int = 3) -> str:
    """Знайти k найсхожіших фрагментів бази знань магазину (повернення, доставка, оплата, гарантія, замовлення, контакти).
    Повертає JSON-список об'єктів {source, text}."""
    global _index
    if _index is None:
        _index = _load_index()
    qv = _embeddings().embed_query(query)
    ranked = sorted(_index, key=lambda c: _cosine(qv, c["vector"]), reverse=True)[:k]
    return json.dumps([{"source": c["source"], "text": c["text"]} for c in ranked], ensure_ascii=False)


# ---------- замовлення ----------

def _orders() -> dict:
    orders = json.loads(ORDERS_FILE.read_text(encoding="utf-8"))
    refunds = json.loads(REFUNDS_FILE.read_text(encoding="utf-8")) if REFUNDS_FILE.exists() else {}
    for order_id in refunds:
        orders[order_id]["status"] = "повернення оформлено"
    return orders


@mcp.tool()
def get_order(order_id: str) -> str:
    """Статус і склад замовлення за номером у форматі A-1234. Повертає JSON або повідомлення, що замовлення не знайдено."""
    order = _orders().get(order_id.strip().upper())
    if order is None:
        return json.dumps({"error": f"Замовлення {order_id} не знайдено"}, ensure_ascii=False)
    return json.dumps({"order_id": order_id, **order}, ensure_ascii=False)


@mcp.tool()
def issue_refund(order_id: str, reason: str) -> str:
    """Оформити повернення коштів за замовленням. Сервер сам перевіряє правила: замовлення доставлене,
    минуло не більше 14 днів, повернення ще не оформлювали."""
    order_id = order_id.strip().upper()
    order = _orders().get(order_id)
    if order is None:
        return f"На жаль, оформити повернення не можна: замовлення {order_id} не знайдено."
    if order["status"] != "доставлено":
        return f"На жаль, оформити повернення не можна: статус замовлення {order_id} - «{order['status']}»."
    days = (TODAY - date.fromisoformat(order["delivered_at"])).days
    if days > RETURN_DAYS:
        return (f"На жаль, оформити повернення не можна: замовлення {order_id} отримано {order['delivered_at']}, "
                f"а повернути товар можна протягом {RETURN_DAYS} днів (минуло днів: {days}).")
    refunds = json.loads(REFUNDS_FILE.read_text(encoding="utf-8")) if REFUNDS_FILE.exists() else {}
    refunds[order_id] = {"reason": reason, "date": TODAY.isoformat()}
    REFUNDS_FILE.write_text(json.dumps(refunds, ensure_ascii=False, indent=1), encoding="utf-8")
    return (f"Повернення за замовленням {order_id} оформлено (причина: {reason}). "
            f"Кур'єр забере товар протягом 3 робочих днів, гроші ({order['total_uah']} грн) повернуться тим самим способом оплати ({order['payment']}).")


# ---------- ресурс: документи бази знань для читання клієнтом ----------

@mcp.resource("kb://{name}")
def knowledge_document(name: str) -> str:
    """Повний текст документа бази знань (returns, delivery, payment, warranty, orders, contacts)."""
    return (CORPUS_DIR / f"{name}.md").read_text(encoding="utf-8")


if __name__ == "__main__":
    if "--http" in sys.argv:
        mcp.settings.port = int(os.getenv("MCP_PORT", "8001"))
        mcp.run(transport="streamable-http")
    else:
        mcp.run()
