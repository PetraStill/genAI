"""Ворота релізу: eval на датасеті з еталонами + пороги бізнесу. Код виходу 1 блокує реліз у CI.

    python eval_gate.py                       # перевірити збережені трейси evals/runs_mcp.json (без LLM)
    python eval_gate.py --runs evals/runs_v2.json
    python eval_gate.py --rerun               # прогнати агента з MCP наново (~100 викликів LLM), зберегти й перевірити
"""

import argparse
import asyncio
import json
import sys
from pathlib import Path

from evaluation import EVALS_DIR, load_dataset

FALLBACK = "На жаль, я не знайшов відповіді в базі знань. Передаю ваше питання оператору — він зв'яжеться з вами найближчим часом."

# метрика: (min або max, поріг) - пороги задає бізнес, а не розробник
GATES = {
    "галюцинації": ("max", 0.0),
    "хибні відмови": ("max", 0.10),
    "факти правильні": ("min", 0.90),
    "намір визначено": ("min", 0.95),
    "повернення на паузі з правильним номером": ("min", 1.0),
}


def has_facts(answer: str, facts: list[list[str]]) -> bool:
    return all(any(variant.lower() in answer.lower() for variant in group) for group in facts)


def release_metrics(traces: list[dict], dataset: list[dict]) -> dict:
    t = {x["id"]: x for x in traces}
    in_base = [c for c in dataset if c["kind"] == "в базі"]
    out_base = [c for c in dataset if c["kind"] == "поза базою"]
    refunds = [c for c in dataset if c["kind"] == "повернення"]
    answered = [c for c in in_base if t[c["id"]]["answer"] != FALLBACK]
    expected_intent = {"в базі": "question", "поза базою": "question", "повернення": "refund", "неоднозначний": "refund"}
    return {
        "галюцинації": sum(t[c["id"]]["answer"] != FALLBACK for c in out_base) / len(out_base),
        "хибні відмови": sum(t[c["id"]]["answer"] == FALLBACK for c in in_base) / len(in_base),
        "факти правильні": sum(has_facts(t[c["id"]]["answer"], c["facts"]) for c in answered) / max(len(answered), 1),
        "намір визначено": sum(t[c["id"]]["intent"] == expected_intent[c["kind"]] for c in dataset) / len(dataset),
        "повернення на паузі з правильним номером": sum(
            (t[c["id"]]["paused"] or {}).get("order_id") == c["order_id"] for c in refunds) / len(refunds),
    }


def gate(metrics: dict) -> list[str]:
    failed = []
    for name, (kind, limit) in GATES.items():
        if (kind == "max" and metrics[name] > limit) or (kind == "min" and metrics[name] < limit):
            failed.append(f"{name} = {metrics[name]:.0%} (поріг: {kind} {limit:.0%})")
    return failed


async def rerun() -> list[dict]:
    from langchain_mcp_adapters.client import MultiServerMCPClient
    from langchain_mcp_adapters.tools import load_mcp_tools

    from agent_mcp import build_mcp_graph
    from evaluation import acollect

    client = MultiServerMCPClient({"shop": {"transport": "stdio", "command": sys.executable,
                                            "args": [str(Path(__file__).parent / "shop_mcp.py")]}})
    async with client.session("shop") as session:
        graph = build_mcp_graph(await load_mcp_tools(session))
        return await acollect(graph, load_dataset(), "mcp", rerun=True)


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8")  # Windows: інакше ✅/⛔ не друкуються, коли вивід іде в pipe або CI-лог
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--runs", default=str(EVALS_DIR / "runs_mcp.json"), help="файл зі збереженими трейсами")
    parser.add_argument("--rerun", action="store_true", help="прогнати агента наново перед перевіркою")
    args = parser.parse_args()

    traces = asyncio.run(rerun()) if args.rerun else json.loads(Path(args.runs).read_text(encoding="utf-8"))
    metrics = release_metrics(traces, load_dataset())
    for name, value in metrics.items():
        kind, limit = GATES[name]
        print(f"{'✅' if (value <= limit if kind == 'max' else value >= limit) else '⛔'} {name}: {value:.0%} (поріг {kind} {limit:.0%})")
    failed = gate(metrics)
    print("\nРеліз дозволено" if not failed else "\nРеліз заблоковано: " + "; ".join(failed))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
