"""Сервіс агента «ЇжакМаркет»: HTTP API + MCP-інструменти + пам'ять у SQLite + журнал онлайн-метрик.

Запуск локально:
    uvicorn app:app --port 8000          # відкрийте http://127.0.0.1:8000

Налаштування (змінні середовища, див. .env.example):
    OPERATOR_TOKEN   токен для ендпоінтів оператора; порожній - без захисту (лише для локальної розробки)
    CHECKPOINT_DB    шлях до SQLite-файлу з пам'яттю діалогів (за замовчуванням data/checkpoints.sqlite)
    MCP_URL          адреса MCP-сервера по HTTP; якщо не задано, сервіс сам запускає shop_mcp.py через stdio
"""

import json
import logging
import os
import sys
import time
import uuid
from contextlib import AsyncExitStack, asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal

from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.responses import FileResponse
from langchain_core.messages import HumanMessage
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_mcp_adapters.tools import load_mcp_tools
from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver
from langgraph.types import Command
from pydantic import BaseModel, Field

from agent_mcp import FALLBACK, build_mcp_graph
from evaluation import LLMCounter

ROOT = Path(__file__).parent
DATA_DIR = ROOT / "data"
CHECKPOINT_DB = os.getenv("CHECKPOINT_DB", str(DATA_DIR / "checkpoints.sqlite"))
REQUEST_LOG = DATA_DIR / "requests.jsonl"
OPERATOR_TOKEN = os.getenv("OPERATOR_TOKEN", "")
MCP_URL = os.getenv("MCP_URL", "")
WAITING = "Запит на повернення передано оператору на підтвердження. Відповідь з'явиться тут."

# Сторонні бібліотеки - лише попередження й помилки, наш журнал - докладніше
logging.basicConfig(level=logging.WARNING, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("ijak-market")
log.setLevel(logging.INFO)


def mcp_connection() -> dict:
    if MCP_URL:
        return {"transport": "streamable_http", "url": MCP_URL}
    return {"transport": "stdio", "command": sys.executable, "args": [str(ROOT / "shop_mcp.py")]}


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Усе довгоживуче відкривається один раз на старті й коректно закривається на зупинці."""
    DATA_DIR.mkdir(exist_ok=True)
    async with AsyncExitStack() as stack:
        session = await stack.enter_async_context(MultiServerMCPClient({"shop": mcp_connection()}).session("shop"))
        saver = await stack.enter_async_context(AsyncSqliteSaver.from_conn_string(CHECKPOINT_DB))
        await saver.conn.execute("CREATE TABLE IF NOT EXISTS approvals ("
                                 "thread_id TEXT PRIMARY KEY, order_id TEXT, reason TEXT, created_at TEXT)")
        await saver.conn.commit()
        app.state.db = saver.conn
        app.state.graph = build_mcp_graph(await load_mcp_tools(session), checkpointer=saver)
        log.info("Сервіс готовий: MCP %s, пам'ять %s", MCP_URL or "stdio", CHECKPOINT_DB)
        yield


app = FastAPI(title="ЇжакМаркет: агент підтримки", lifespan=lifespan)


# ---------- моделі запитів і відповідей ----------

class ChatIn(BaseModel):
    message: str = Field(min_length=1, max_length=2000)
    thread_id: str | None = Field(default=None, description="ідентифікатор діалогу; без нього починається новий")


class ChatOut(BaseModel):
    thread_id: str
    status: Literal["answered", "waiting_approval"]
    answer: str
    path: list[str]


class DecisionIn(BaseModel):
    decision: Literal["yes", "no"]


def require_operator(x_operator_token: str = Header(default="")):
    if OPERATOR_TOKEN and x_operator_token != OPERATOR_TOKEN:
        raise HTTPException(status_code=401, detail="Потрібен коректний X-Operator-Token")


# ---------- запуск графа з журналом метрик ----------

async def run_graph(graph_input, thread_id: str, kind: str) -> ChatOut:
    counter = LLMCounter()
    config = {"configurable": {"thread_id": thread_id}, "callbacks": [counter],
              "run_name": "support-agent", "tags": ["service", kind]}
    path, paused = [], None
    started = time.perf_counter()
    try:
        async for step in app.state.graph.astream(graph_input, config, stream_mode="updates"):
            for node, _ in step.items():
                if node == "__interrupt__":
                    paused = step[node][0].value
                else:
                    path.append(node)
    except Exception:
        log.exception("Помилка графа в треді %s", thread_id)
        raise HTTPException(status_code=502, detail="Агент тимчасово недоступний, спробуйте ще раз за хвилину")
    state = (await app.state.graph.aget_state(config)).values
    answer = WAITING if paused else state.get("answer", "")
    if paused:
        await app.state.db.execute("INSERT OR REPLACE INTO approvals VALUES (?, ?, ?, ?)",
                                   (thread_id, paused["order_id"], paused["reason"], datetime.now(timezone.utc).isoformat()))
        await app.state.db.commit()
    record = {"ts": datetime.now(timezone.utc).isoformat(), "thread_id": thread_id, "kind": kind,
              "intent": state.get("intent"), "path": path, "paused": paused is not None,
              "fallback": answer == FALLBACK, "rejected_by_grounding": "generate" in path and "fallback" in path,
              "llm_calls": counter.calls, "tokens": counter.input_tokens + counter.output_tokens,
              "seconds": round(time.perf_counter() - started, 2)}
    with REQUEST_LOG.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")
    return ChatOut(thread_id=thread_id, status="waiting_approval" if paused else "answered", answer=answer, path=path)


# ---------- ендпоінти клієнта ----------

@app.post("/chat", response_model=ChatOut)
async def chat(body: ChatIn):
    thread_id = body.thread_id or str(uuid.uuid4())
    return await run_graph({"messages": [HumanMessage(body.message)]}, thread_id, kind="chat")


@app.get("/threads/{thread_id}")
async def thread_history(thread_id: str):
    """Історія діалогу з checkpointer'а: переживає перезапуск сервісу."""
    state = await app.state.graph.aget_state({"configurable": {"thread_id": thread_id}})
    messages = [{"role": "client" if m.type == "human" else "agent", "text": m.content} for m in state.values.get("messages", [])]
    return {"thread_id": thread_id, "messages": messages, "waiting_approval": bool(state.next)}


# ---------- ендпоінти оператора ----------

@app.get("/approvals", dependencies=[Depends(require_operator)])
async def list_approvals():
    rows = await (await app.state.db.execute("SELECT thread_id, order_id, reason, created_at FROM approvals ORDER BY created_at")).fetchall()
    return [{"thread_id": r[0], "order_id": r[1], "reason": r[2], "created_at": r[3]} for r in rows]


@app.post("/approvals/{thread_id}", response_model=ChatOut, dependencies=[Depends(require_operator)])
async def decide(thread_id: str, body: DecisionIn):
    state = await app.state.graph.aget_state({"configurable": {"thread_id": thread_id}})
    if not state.next:
        raise HTTPException(status_code=404, detail="Цей діалог не чекає на підтвердження")
    result = await run_graph(Command(resume=body.decision), thread_id, kind="approval")
    await app.state.db.execute("DELETE FROM approvals WHERE thread_id = ?", (thread_id,))
    await app.state.db.commit()
    return result


@app.get("/metrics", dependencies=[Depends(require_operator)])
async def metrics():
    """Онлайн-метрики з 06_judge_production, пораховані з журналу запитів (без еталона)."""
    if not REQUEST_LOG.exists():
        return {"requests": 0}
    records = [json.loads(line) for line in REQUEST_LOG.read_text(encoding="utf-8").splitlines() if line]
    chats = [r for r in records if r["kind"] == "chat"]
    questions = [r for r in chats if r["intent"] == "question"]
    seconds = sorted(r["seconds"] for r in chats) or [0]
    return {
        "requests": len(chats),
        "fallback_rate": round(sum(r["fallback"] for r in questions) / max(len(questions), 1), 2),
        "rejected_by_grounding_rate": round(sum(r["rejected_by_grounding"] for r in questions) / max(len(questions), 1), 2),
        "llm_calls_per_request": round(sum(r["llm_calls"] for r in chats) / max(len(chats), 1), 1),
        "p95_seconds": seconds[min(len(seconds) - 1, int(0.95 * len(seconds)))],
        "waiting_approvals": (await (await app.state.db.execute("SELECT COUNT(*) FROM approvals")).fetchone())[0],
    }


# ---------- службове ----------

@app.get("/health")
async def health():
    return {"status": "ok"}


@app.get("/")
async def index():
    return FileResponse(ROOT / "static" / "index.html", headers={"Cache-Control": "no-cache"})
